>> View Pdf in [Sharelatex](https://www.sharelatex.com/github/repos/sudhargk/video-annotator/builds/latest/output.pdf) 

>> Status [![PDF Status](https://www.sharelatex.com/github/repos/sudhargk/video-annotator/builds/latest/badge.svg)](https://www.sharelatex.com/github/repos/sudhargk/video-annotator/builds/latest/output.pdf) 
